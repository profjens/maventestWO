The webserver-resources source folder is intended for split installs. i.e., resources placed
here will, in a deployment environment, be served directly by the webserver (e.g., apache).
